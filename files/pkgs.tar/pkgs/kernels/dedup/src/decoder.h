#ifndef _DECODER_H_
#define _DECODER_H_ 1

#include "dedupdef.h"

void Decode(config_t * _conf);

#endif /* !_DECODER_H_ */
